@echo off
echo Installing DICOM processing packages...
cd /d "%~dp0ai-service"
call venv\Scripts\activate
pip install pydicom==2.4.4 Pillow==10.3.0 numpy==1.26.4
echo.
echo Done! Restart the AI service for changes to take effect.
pause
