@echo off
REM ============================================================
REM  Hospital Management System — Full Stack Launcher
REM  يشغل: MongoDB + Node.js + FastAPI + React
REM ============================================================

title Hospital Management — Launcher
color 0A

echo.
echo  ===============================================
echo   HOSPITAL MANAGEMENT SYSTEM — STARTING...
echo  ===============================================
echo.

REM ── تحقق من Ollama ─────────────────────────────────────────────
echo [1/4] Checking Ollama...
ollama list >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] Ollama not found or not running.
    echo        Start it manually: ollama serve
    echo.
) else (
    echo [OK] Ollama found.
    REM تشغيل Ollama في الخلفية
    start "Ollama" /min cmd /c "ollama serve"
    timeout /t 2 >nul
    echo [OK] Ollama serve started.
)

REM ── Node.js Backend ────────────────────────────────────────────
echo.
echo [2/4] Starting Node.js Backend (port 5005)...
cd /d "%~dp0backend"
start "Backend (Node.js)" cmd /k "set NODE_OPTIONS=--dns-result-order=ipv4first && npm run dev"
timeout /t 3 >nul

REM ── FastAPI AI Service ─────────────────────────────────────────
echo.
echo [3/4] Starting FastAPI AI Service (port 8000)...
cd /d "%~dp0ai-service"

REM تحقق من وجود venv
if exist "venv\Scripts\activate.bat" (
    start "AI Service (FastAPI)" cmd /k "venv\Scripts\activate.bat && python main.py"
) else (
    echo [WARN] Virtual env not found, trying global python...
    start "AI Service (FastAPI)" cmd /k "python main.py"
)
timeout /t 5 >nul

REM ── React Frontend ─────────────────────────────────────────────
echo.
echo [4/4] Starting React Frontend (port 5173)...
cd /d "%~dp0frontend"
start "Frontend (React)" cmd /k "npm run dev"
timeout /t 4 >nul

REM ── Summary ────────────────────────────────────────────────────
echo.
echo  ===============================================
echo   ALL SERVICES STARTED
echo  ===============================================
echo.
echo   Frontend  : http://localhost:5173
echo   Backend   : http://localhost:5005
echo   AI Service: http://localhost:8000
echo   AI Docs   : http://localhost:8000/docs
echo   Ollama    : http://localhost:11434
echo.
echo  Press any key to open the app in browser...
pause >nul
start http://localhost:5173

echo.
echo  Close this window to keep services running.
pause
