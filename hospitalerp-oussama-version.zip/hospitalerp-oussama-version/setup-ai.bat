@echo off
REM ============================================================
REM  Hospital AI Service — Setup Script
REM  شغّله مرة واحدة فقط لتثبيت كل المكتبات
REM ============================================================

title Hospital AI Service — Setup
color 0B

echo.
echo  ===============================================
echo   AI SERVICE SETUP
echo  ===============================================
echo.

cd /d "%~dp0ai-service"

REM ── Python check ──────────────────────────────────────────────
echo [1/5] Checking Python version...
python --version 2>&1 | findstr /R "3\.[89]\|3\.1[0-9]" >nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.8+ required. Please install from python.org
    pause
    exit /b 1
)
echo [OK] Python version OK.

REM ── Virtual Environment ───────────────────────────────────────
echo.
echo [2/5] Creating virtual environment...
if exist "venv" (
    echo [SKIP] venv already exists.
) else (
    python -m venv venv
    echo [OK] venv created.
)

REM ── Activate venv ─────────────────────────────────────────────
call venv\Scripts\activate.bat
echo [OK] venv activated.

REM ── Upgrade pip ───────────────────────────────────────────────
echo.
echo [3/5] Upgrading pip...
python -m pip install --upgrade pip --quiet

REM ── Install requirements ──────────────────────────────────────
echo.
echo [4/5] Installing requirements...
echo       (this may take several minutes on first run)
echo       Packages: FastAPI, sentence-transformers, ChromaDB, LangChain...
echo.
pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Installation failed. Check your internet connection.
    pause
    exit /b 1
)
echo.
echo [OK] All packages installed successfully.

REM ── Download Ollama model ──────────────────────────────────────
echo.
echo [5/5] Checking Ollama model...
ollama list >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARN] Ollama not accessible. Install from https://ollama.ai
    echo        Then run: ollama pull mistral
) else (
    echo [INFO] Downloading mistral model (4.1 GB — first time only)...
    ollama pull mistral
    echo [OK] Model ready.
)

REM ── Create .env from example ───────────────────────────────────
if not exist ".env" (
    echo.
    echo [INFO] Creating .env file...
    copy .env .env.backup >nul 2>&1
    echo [OK] .env file ready. Edit MONGODB_URI if needed.
)

REM ── Done ──────────────────────────────────────────────────────
echo.
echo  ===============================================
echo   SETUP COMPLETE
echo  ===============================================
echo.
echo   To start the AI service:
echo     cd ai-service
echo     venv\Scripts\activate
echo     python main.py
echo.
echo   Or run start-all.bat from the project root.
echo.
pause
